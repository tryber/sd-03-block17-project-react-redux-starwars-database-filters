import React from 'react';

const Loading = () => (
  <p>Loading...</p>
);

export default Loading;
